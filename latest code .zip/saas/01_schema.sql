-- ============================================================================
-- Workshop Manager SaaS — STEP 1 : schema + security (Supabase SQL Editor mein ek baar run karo)
-- Multi-garage: har garage ka apna workshop_id, ek garage ka data dusre ko kabhi nahi dikhta (RLS).
-- 45-din trial + subscription state database khud calculate karta hai (cron ki zaroorat nahi).
-- ============================================================================

-- ---------- tables ----------
create table if not exists public.workshops (
  id               uuid primary key default gen_random_uuid(),
  name             text not null,
  owner_id         uuid,
  trial_started_at timestamptz not null default now(),
  trial_ends_at    timestamptz not null default (now() + interval '45 days'),
  paid_until       timestamptz,                  -- subscription is date tak valid (sirf verified payment se set hota hai)
  suspended        boolean not null default false,
  plan             text,
  notes            text,
  created_at       timestamptz not null default now()
);

create table if not exists public.members (
  user_id      uuid primary key references auth.users(id) on delete cascade,   -- ek user = ek garage
  workshop_id  uuid not null references public.workshops(id) on delete cascade,
  role         text not null default 'staff' check (role in ('owner','staff')),
  created_at   timestamptz not null default now()
);
create index if not exists members_workshop_idx on public.members(workshop_id);

create table if not exists public.super_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create table if not exists public.subscriptions (
  id                       uuid primary key default gen_random_uuid(),
  workshop_id              uuid not null references public.workshops(id) on delete cascade,
  plan                     text not null check (plan in ('monthly','quarterly','yearly')),
  razorpay_subscription_id text unique,
  status                   text not null default 'created',
  current_period_end       timestamptz,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create table if not exists public.payments (
  id                       uuid primary key default gen_random_uuid(),
  workshop_id              uuid not null references public.workshops(id) on delete cascade,
  razorpay_payment_id      text unique,
  razorpay_subscription_id text,
  amount_paise             bigint not null default 0,
  currency                 text not null default 'INR',
  status                   text not null default 'captured',
  plan                     text,
  period_end               timestamptz,
  source                   text not null default 'razorpay',     -- razorpay / manual
  raw                      jsonb,
  created_at               timestamptz not null default now()
);
create index if not exists payments_workshop_idx on public.payments(workshop_id, created_at desc);

-- records (jobs / catalog / bookings / expenses / purchases / settings): ab har row ek garage ki
create table if not exists public.records (
  workshop_id uuid        references public.workshops(id) on delete cascade,
  kind        text        not null,
  id          text        not null,
  data        jsonb,
  deleted     boolean     not null default false,
  updated_at  timestamptz not null default now(),
  updated_by  uuid,
  primary key (workshop_id, kind, id)
);
-- purani (single-garage) table ho to bas column jud jayega; PK 02_first_garage.sql mein badlegi
alter table public.records add column if not exists workshop_id uuid references public.workshops(id) on delete cascade;
create index if not exists records_updated_at_idx on public.records (workshop_id, updated_at);

-- ---------- helper functions ----------
create or replace function public.touch_records() returns trigger language plpgsql as $$
begin new.updated_at := clock_timestamp(); new.updated_by := auth.uid(); return new; end $$;
drop trigger if exists records_touch on public.records;
create trigger records_touch before insert or update on public.records for each row execute function public.touch_records();

create or replace function public.my_workshop_id() returns uuid
language sql stable security definer set search_path = public as
$$ select workshop_id from public.members where user_id = auth.uid() $$;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.super_admins where user_id = auth.uid()) $$;

-- trial / active / expired / suspended  (ghadi se khud nikalta hai)
create or replace function public._state(w public.workshops) returns text
language sql stable as
$$ select case
     when w.suspended then 'suspended'
     when w.paid_until is not null and w.paid_until > now() then 'active'
     when w.trial_ends_at > now() then 'trial'
     else 'expired' end $$;

create or replace function public.workshop_can_write(w_id uuid) returns boolean
language sql stable security definer set search_path = public as
$$ select coalesce((select public._state(x) in ('trial','active') from public.workshops x where x.id = w_id), false) $$;

-- app ye call karke apna garage, state aur bache hue din jaanta hai
create or replace function public.my_workshop() returns json
language plpgsql stable security definer set search_path = public as $$
declare r json;
begin
  select json_build_object(
    'id', w.id, 'name', w.name, 'role', m.role, 'state', public._state(w),
    'trial_ends_at', w.trial_ends_at, 'paid_until', w.paid_until, 'server_now', now(),
    'days_left', greatest(0, ceil(extract(epoch from ((case when public._state(w) = 'active' then w.paid_until else w.trial_ends_at end) - now())) / 86400))::int,
    'is_admin', public.is_super_admin())
  into r
  from public.members m join public.workshops w on w.id = m.workshop_id
  where m.user_id = auth.uid();
  if r is null then r := json_build_object('id', null, 'is_admin', public.is_super_admin()); end if;
  return r;
end $$;

-- ---------- Row Level Security ----------
alter table public.records       enable row level security;
alter table public.workshops     enable row level security;
alter table public.members       enable row level security;
alter table public.super_admins  enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments      enable row level security;

drop policy if exists "staff full access" on public.records;          -- purani sab-ko-sab policy hatao
drop policy if exists rec_select on public.records;
drop policy if exists rec_insert on public.records;
drop policy if exists rec_update on public.records;
drop policy if exists rec_delete on public.records;
create policy rec_select on public.records for select to authenticated
  using (workshop_id = public.my_workshop_id());
create policy rec_insert on public.records for insert to authenticated
  with check (workshop_id = public.my_workshop_id() and public.workshop_can_write(workshop_id));
create policy rec_update on public.records for update to authenticated
  using (workshop_id = public.my_workshop_id() and public.workshop_can_write(workshop_id))
  with check (workshop_id = public.my_workshop_id() and public.workshop_can_write(workshop_id));
create policy rec_delete on public.records for delete to authenticated
  using (workshop_id = public.my_workshop_id() and public.workshop_can_write(workshop_id));

drop policy if exists ws_select on public.workshops;
create policy ws_select on public.workshops for select to authenticated
  using (id = public.my_workshop_id() or public.is_super_admin());
drop policy if exists mem_select on public.members;
create policy mem_select on public.members for select to authenticated
  using (user_id = auth.uid() or public.is_super_admin());
drop policy if exists sub_select on public.subscriptions;
create policy sub_select on public.subscriptions for select to authenticated
  using (workshop_id = public.my_workshop_id() or public.is_super_admin());
drop policy if exists pay_select on public.payments;
create policy pay_select on public.payments for select to authenticated
  using (workshop_id = public.my_workshop_id() or public.is_super_admin());
-- super_admins par koi policy nahi: app se koi nahi padh/badal sakta

revoke all on public.records, public.workshops, public.members, public.super_admins, public.subscriptions, public.payments from anon, authenticated;
grant select, insert, update, delete on public.records to authenticated;
grant select on public.workshops, public.members, public.subscriptions, public.payments to authenticated;

-- ---------- Super Admin functions (sirf super_admins table wale user chala sakte hain) ----------
create or replace function public._need_admin() returns void language plpgsql stable as $$
begin
  -- super admin user, ya project owner jo Supabase SQL Editor (postgres) se chala raha ho
  if not (public.is_super_admin() or session_user in ('postgres','supabase_admin')) then raise exception 'not allowed' using errcode = '42501'; end if;
end $$;

create or replace function public.admin_overview() returns json
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._need_admin();
  return (select json_build_object(
    'total',     count(*),
    'trial',     count(*) filter (where public._state(w) = 'trial'),
    'active',    count(*) filter (where public._state(w) = 'active'),
    'expired',   count(*) filter (where public._state(w) = 'expired'),
    'suspended', count(*) filter (where public._state(w) = 'suspended'),
    'revenue_paise', (select coalesce(sum(amount_paise), 0) from public.payments where status = 'captured'))
    from public.workshops w);
end $$;

create or replace function public.admin_list_workshops() returns table (
  id uuid, name text, owner_email text, state text, days_left int, trial_started_at timestamptz, trial_ends_at timestamptz,
  paid_until timestamptz, suspended boolean, plan text, notes text, created_at timestamptz, last_payment_at timestamptz, jobs_count bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._need_admin();
  return query
  select w.id, w.name, (select u.email::text from auth.users u where u.id = w.owner_id), public._state(w),
         greatest(0, ceil(extract(epoch from ((case when public._state(w) = 'active' then w.paid_until else w.trial_ends_at end) - now())) / 86400))::int,
         w.trial_started_at, w.trial_ends_at, w.paid_until, w.suspended, w.plan, w.notes, w.created_at,
         (select max(p.created_at) from public.payments p where p.workshop_id = w.id and p.status = 'captured'),
         (select count(*) from public.records r where r.workshop_id = w.id and r.kind = 'jobs' and not r.deleted)
  from public.workshops w order by w.created_at desc;
end $$;

create or replace function public.admin_create_workshop(p_name text, p_owner_email text, p_trial_days int default 45) returns uuid
language plpgsql security definer set search_path = public as $$
declare u uuid; w uuid;
begin
  perform public._need_admin();
  select id into u from auth.users where lower(email) = lower(trim(p_owner_email));
  if u is null then raise exception 'User nahi mila: pehle Supabase Authentication > Users mein % ka user banao', p_owner_email; end if;
  if exists (select 1 from public.members where user_id = u) then raise exception 'Ye user pehle se kisi garage se juda hai'; end if;
  insert into public.workshops(name, owner_id, trial_started_at, trial_ends_at)
    values (trim(p_name), u, now(), now() + make_interval(days => p_trial_days)) returning id into w;
  insert into public.members(user_id, workshop_id, role) values (u, w, 'owner');
  return w;
end $$;

create or replace function public.admin_extend_trial(p_workshop uuid, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._need_admin();
  update public.workshops set trial_ends_at = greatest(trial_ends_at, now()) + make_interval(days => p_days) where id = p_workshop;
end $$;

create or replace function public.admin_set_suspended(p_workshop uuid, p_suspended boolean) returns void
language plpgsql security definer set search_path = public as $$
begin perform public._need_admin(); update public.workshops set suspended = p_suspended where id = p_workshop; end $$;

create or replace function public.admin_set_paid_until(p_workshop uuid, p_until timestamptz, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._need_admin();
  update public.workshops set paid_until = p_until where id = p_workshop;
  insert into public.payments(workshop_id, amount_paise, status, source, period_end, raw)
    values (p_workshop, 0, 'manual', 'manual', p_until, jsonb_build_object('note', p_note, 'by', auth.uid()));
end $$;

create or replace function public.admin_update_workshop(p_workshop uuid, p_name text, p_notes text, p_plan text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._need_admin();
  update public.workshops set name = coalesce(nullif(trim(p_name), ''), name), notes = p_notes, plan = p_plan where id = p_workshop;
end $$;

create or replace function public.admin_payments(p_workshop uuid default null) returns table (
  id uuid, workshop_id uuid, workshop_name text, amount_paise bigint, status text, plan text, source text,
  razorpay_payment_id text, period_end timestamptz, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._need_admin();
  return query select p.id, p.workshop_id, w.name, p.amount_paise, p.status, p.plan, p.source, p.razorpay_payment_id, p.period_end, p.created_at
    from public.payments p join public.workshops w on w.id = p.workshop_id
    where p_workshop is null or p.workshop_id = p_workshop order by p.created_at desc limit 500;
end $$;

-- ---------- Payment webhook helper (sirf server / service_role) ----------
-- Razorpay ka verified webhook aane par hi paid_until badhta hai. Same payment dobara aaye to kuch double nahi hota.
create or replace function public.apply_payment(p_workshop uuid, p_payment_id text, p_subscription_id text, p_amount_paise bigint,
                                                p_plan text, p_period_end timestamptz, p_raw jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into public.payments(workshop_id, razorpay_payment_id, razorpay_subscription_id, amount_paise, status, plan, period_end, raw)
    values (p_workshop, p_payment_id, p_subscription_id, p_amount_paise, 'captured', p_plan, p_period_end, p_raw)
    on conflict (razorpay_payment_id) do nothing;
  get diagnostics n = row_count;
  if n = 0 then return false; end if;
  update public.workshops set paid_until = greatest(coalesce(paid_until, now()), p_period_end), plan = coalesce(p_plan, plan) where id = p_workshop;
  update public.subscriptions set status = 'active', current_period_end = p_period_end, updated_at = now() where razorpay_subscription_id = p_subscription_id;
  return true;
end $$;

-- function permissions: admin_* sirf login user; apply_payment sirf service_role
do $$
declare f text;
begin
  for f in select p.oid::regprocedure::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and (p.proname like 'admin\_%' or p.proname in ('my_workshop','_need_admin','is_super_admin','my_workshop_id','workshop_can_write','apply_payment','_state'))
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f);
  end loop;
end $$;
grant execute on function public.my_workshop() to authenticated;
grant execute on function public.my_workshop_id(), public.is_super_admin(), public.workshop_can_write(uuid), public._state(public.workshops), public._need_admin() to authenticated;
grant execute on function public.admin_overview(), public.admin_list_workshops(), public.admin_create_workshop(text, text, int), public.admin_extend_trial(uuid, int),
  public.admin_set_suspended(uuid, boolean), public.admin_set_paid_until(uuid, timestamptz, text), public.admin_update_workshop(uuid, text, text, text), public.admin_payments(uuid) to authenticated;
do $$ begin if exists (select 1 from pg_roles where rolname = 'service_role') then
  execute 'grant execute on function public.apply_payment(uuid, text, text, bigint, text, timestamptz, jsonb) to service_role';
end if; end $$;
