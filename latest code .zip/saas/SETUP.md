# Workshop Manager v5 — Multi-garage (Stage 1–3) setup

Ye update ek saath 3 kaam karta hai: har garage ka alag data (workshop_id + RLS), 45-din trial, aur trial/plan khatam hone par app lock.
**Teeno steps ek hi baithak mein karo** (SQL chalate hi purana app naye database se baat nahi kar paata, jab tak naya index.html deploy na ho).

## Pehle (ek baar)
1. Supabase → **Authentication → Users → Add user**: apna *admin* email + password banao (Auto Confirm ON). Ye tum Super Admin ho.
2. Supabase → **Authentication → Sign In / Providers**: "Allow new users to sign up" = **OFF** (sirf admin garage banayega).
3. Agar tumhara purana garage pehle se Users mein hai (jo app mein login karta tha) to uska email yaad rakho.

## Step 1 — Database
Supabase → **SQL Editor → New query** → `01_schema.sql` ka **poora** text paste → **Run**. "Success" aana chahiye.

## Step 2 — Purana data pehle garage mein
`02_first_garage.sql` kholo, upar ki 3 values badlo:
- `OWNER_EMAIL_YAHAN` → purane garage ka login email
- `GARAGE_NAAM_YAHAN` → jaise Pulse Auto Care
- `APNA_ADMIN_EMAIL_YAHAN` → tumhara admin email (upar Pehle-1 wala)

Phir SQL Editor mein paste → Run. (Purane data ke sab records is garage ke ho jayenge. Dobara run karna safe hai.)
Agar purana data nahi chahiye (fresh start) to sirf Step 3 wali SQL chalao.

## Step 3 — Naya garage banana (har naye customer ke liye)
1. Authentication → Users → **Add user** (garage owner ka email + password, Auto Confirm ON).
2. SQL Editor mein ye chalao (SQL Editor project owner ke naam se chalta hai, isliye seedha kaam karta hai):
```
select public.admin_create_workshop('Garage Ka Naam','owner@email.com');
```
Ye garage banata hai aur **aaj se 45 din** ka trial shuru karta hai. (Stage 5 mein ye Admin Panel ke ek button se hoga.)

## Step 4 — Naya app deploy
Netlify → apna site → Deploys → naya `index.html` drag-drop. Upar **CLOUD v5** dikhna chahiye. Login karo: upar **"Free trial: N din baaki"** bar dikhega.

## Kaise kaam karta hai
- Trial: admin garage banata hai → 45 din. Din bachne ka bar har page par. Last 7 din mein "Plan lein" button.
- Trial/plan khatam: app lock screen — sirf "Renew", "data backup" aur "Logout". Data delete nahi hota; database mein pada rehta hai.
- Renew (verified payment) hote hi `paid_until` set hota hai aur app apne aap khul jata hai (Stage 4 mein payment gateway judega; tab tak admin manual activate kar sakta hai).
- Ek garage ka data doosre ko kabhi nahi dikhta — ye database (Row Level Security) khud rokta hai, app ka bharosa nahi.
- Admin ke SQL functions: `admin_overview()`, `admin_list_workshops()`, `admin_extend_trial(id, days)`, `admin_set_suspended(id, true/false)`, `admin_set_paid_until(id, date)`, `admin_payments()`.
