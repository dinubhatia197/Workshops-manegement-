-- ============================================================================
-- STEP 2 (sirf agar purana single-garage data hai) : purane data ko PEHLE GARAGE mein badlo
-- Neeche 3 values apni badlo, phir Run karo. 01_schema.sql pehle run ho chuka hona chahiye.
-- ============================================================================
do $$
declare
  v_owner_email    text := 'OWNER_EMAIL_YAHAN';        -- purane app mein jo login use hota tha (Authentication > Users mein hona chahiye)
  v_garage_name    text := 'GARAGE_NAAM_YAHAN';        -- jaise: Pulse Auto Care
  v_admin_email    text := 'APNA_ADMIN_EMAIL_YAHAN';   -- tum (Super Admin). Ye bhi Authentication > Users mein hona chahiye
  v_trial_days     int  := 45;
  o uuid; a uuid; w uuid;
begin
  select id into o from auth.users where lower(email) = lower(trim(v_owner_email));
  if o is null then raise exception 'Owner user nahi mila: %', v_owner_email; end if;
  select id into a from auth.users where lower(email) = lower(trim(v_admin_email));
  if a is null then raise exception 'Admin user nahi mila: %', v_admin_email; end if;

  select workshop_id into w from public.members where user_id = o;
  if w is null then
    insert into public.workshops(name, owner_id, trial_started_at, trial_ends_at)
      values (trim(v_garage_name), o, now(), now() + make_interval(days => v_trial_days)) returning id into w;
    insert into public.members(user_id, workshop_id, role) values (o, w, 'owner');
  end if;
  -- baaki purane login (staff) isi garage ke staff ban jayenge (admin ko chhodkar)
  insert into public.members(user_id, workshop_id, role)
    select u.id, w, 'staff' from auth.users u where u.id not in (o, a) and u.id not in (select user_id from public.members);
  insert into public.super_admins(user_id) values (a) on conflict do nothing;

  update public.records set workshop_id = w where workshop_id is null;

  -- primary key ab (workshop_id, kind, id)
  alter table public.records alter column workshop_id set not null;
  if exists (select 1 from pg_constraint where conrelid = 'public.records'::regclass and conname = 'records_pkey'
             and pg_get_constraintdef(oid) not like '%workshop_id%') then
    alter table public.records drop constraint records_pkey;
    alter table public.records add primary key (workshop_id, kind, id);
  end if;
  raise notice 'Pehla garage ban gaya: % (id %)', v_garage_name, w;
end $$;
